# services/gemini_service.py
import os
import time
import logging
from typing import Any, Dict

import httpx
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

logger = logging.getLogger(__name__)

GEMINI_URL = os.getenv("GEMINI_URL", "https://api.gemini.example/v1/generate")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

if not GEMINI_API_KEY:
    logger.warning("GEMINI_API_KEY not set. Calls will fail without a valid key.")

HEADERS = {
    "Authorization": f"Bearer {GEMINI_API_KEY}" if GEMINI_API_KEY else "",
    "Content-Type": "application/json",
}

# Shared async httpx client (keeps connection pooling)
_async_client: httpx.AsyncClient | None = None

def get_client() -> httpx.AsyncClient:
    global _async_client
    if _async_client is None:
        _async_client = httpx.AsyncClient(timeout=10.0)
    return _async_client

class GeminiCallError(Exception):
    pass

@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=2, max=10),
    retry=retry_if_exception_type((httpx.HTTPError, GeminiCallError)),
)
async def call_gemini(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Chama a API Gemini de forma resiliente.
    Retorna JSON decodificado.
    Lance GeminiCallError em caso de resposta inválida.
    """
    client = get_client()
    start = time.time()
    try:
        resp = await client.post(GEMINI_URL, json=payload, headers=HEADERS)
        elapsed = time.time() - start
        logger.info("gemini.call", extra={"status_code": resp.status_code, "elapsed": elapsed})
        resp.raise_for_status()
        data = resp.json()
        # Opcional: extrair estimativa de tokens/custo se a API retornar
        return data
    except httpx.HTTPStatusError as e:
        logger.error("gemini.http_error", exc_info=True, extra={"status_code": e.response.status_code})
        raise GeminiCallError(f"HTTP error from Gemini: {e}") from e
    except httpx.HTTPError as e:
        logger.error("gemini.network_error", exc_info=True)
        raise

# Helper para uso nos routers
async def generate_text(prompt: str, **kwargs) -> Dict[str, Any]:
    payload = {
        "prompt": prompt,
        "max_tokens": kwargs.get("max_tokens", 300),
        "temperature": kwargs.get("temperature", 0.7),
        # adicione campos conforme a spec da Gemini
    }
    return await call_gemini(payload)
