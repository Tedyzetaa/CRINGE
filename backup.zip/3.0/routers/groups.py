# api/routers/groups.py
from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from pydantic import BaseModel
import uuid
import logging
from services.gemini_service import generate_text

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/groups", tags=["groups"])

# === Schemas ===
class GroupMessageSchema(BaseModel):
    group_id: str
    user_id: str
    message: str

# Placeholder: adapte para seu DB/session
def create_task_record(task_id: str, group_id: str, status: str = "queued"):
    # Salve no DB (model TaskTask ou similar). Aqui é um stub.
    logger.info("task.record.create", extra={"task_id": task_id, "group_id": group_id, "status": status})
    return True

def update_task_record(task_id: str, status: str, result: dict | None = None):
    logger.info("task.record.update", extra={"task_id": task_id, "status": status})
    return True

# === Background processing ===
async def process_group_message(payload: dict, task_id: str):
    """
    Função executada em background para chamar as IAs (um exemplo simples).
    Implemente paralelismo controlado / semáforos conforme necessidade.
    """
    try:
        # Exemplo: chamar uma única IA; no seu caso faz loop pelos bots do grupo
        prompt = payload.get("message")
        ai_resp = await generate_text(prompt, max_tokens=400)
        # Persistir resultado (exemplo)
        update_task_record(task_id, "finished", result=ai_resp)
    except Exception as e:
        logger.exception("process_group_message.failure")
        update_task_record(task_id, "error", result={"error": str(e)})

@router.post("/send_message")
async def send_message(payload: GroupMessageSchema, background_tasks: BackgroundTasks):
    # validações básicas
    if not payload.message or not payload.group_id:
        raise HTTPException(status_code=400, detail="group_id and message are required")
    task_id = str(uuid.uuid4())
    create_task_record(task_id, payload.group_id, status="queued")
    background_tasks.add_task(process_group_message, payload.dict(), task_id)
    return {"task_id": task_id, "status": "queued"}
