# tests/test_gemini.py
import respx
import httpx
import pytest
from services import gemini_service

@respx.mock
@pytest.mark.asyncio
async def test_call_gemini_success():
    # ajuste GEMINI_URL se necessário
    url = gemini_service.GEMINI_URL
    stub = respx.post(url).mock(return_value=httpx.Response(200, json={"text": "ok"}))
    resp = await gemini_service.call_gemini({"prompt": "hello"})
    assert resp.get("text") == "ok"
    assert stub.called
